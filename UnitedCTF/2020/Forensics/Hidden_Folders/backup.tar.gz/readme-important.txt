flag-223e55c67d3783f972ed42c0dfab8fad29085d6c


Bravo! Tu as trouvé le flag caché dans le firmware du drone. Le défi est complété.

