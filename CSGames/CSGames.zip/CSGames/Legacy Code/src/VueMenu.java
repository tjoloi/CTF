import javafx.scene.layout.BorderPane;

/**
 * Vue du menu. Classe tr�s simpliste.
 * 
 * @author EquBolduc
 * @version 1.0
 */
public class VueMenu implements Vue {
  public VueMenu() {

  }

  public String getFXML() {
    return "/res/Menu.fxml";
  }

  public void initialiser(BorderPane pane) {

  }

  public void dessiner(double dt) {

  }
}
