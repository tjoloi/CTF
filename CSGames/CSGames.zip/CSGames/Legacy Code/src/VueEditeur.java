/**
 * Vue de l'�diteur.
 * 
 * @author EquBolduc
 * @version 1.0
 */
public class VueEditeur extends VueJeu {
  @Override
  public String getFXML() {
    return "/res/Editeur.fxml";
  }
}
