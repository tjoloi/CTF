print('0'*50)
